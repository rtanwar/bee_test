bee_test
========

testing go webapp with beego in golang

Problem
* display form
* display result based on form value
* display JSON through REST
* display static page with JS& CSS
* use Angular
* 
